DCFNet-Pytorch
============================
This repository is the pytorch implementation for ICML 2018 paper DCFNet: Deep Neural Network with Decomposed Convolutional Filters

For details please refer to [paper](https://arxiv.org/pdf/1802.04145.pdf).

The code for VGG borrows heavily from [torchvision](https://pytorch.org/docs/stable/torchvision/index.html).